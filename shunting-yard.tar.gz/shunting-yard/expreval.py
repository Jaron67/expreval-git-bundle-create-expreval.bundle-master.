class ExpressionEvaluator:
    def __init__(self, invert_precedence=False):
        pass

    def parse(self, expression):
        pass

    def evaluate(self, expression):
        pass
