def matriculation_number():
    pass

def first_name():
    pass

def last_name():
    pass
