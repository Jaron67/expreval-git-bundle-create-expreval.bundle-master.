class Stack:
    def __init__(self):
        pass

    def __len__(self):
        pass

    def __bool__(self):
        pass

    def clear(self):
        pass

    def push(self, item):
        pass

    def pop(self):
        pass

    def peek(self):
        pass
